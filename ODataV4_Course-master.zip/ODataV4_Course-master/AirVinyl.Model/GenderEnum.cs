﻿namespace AirVinyl.Model
{
    public enum Gender
    {
        Female,
        Male,
        Other
    } 
}
