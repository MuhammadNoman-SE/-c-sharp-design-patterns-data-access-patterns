# Building a Consistent RESTful API with OData V4 in ASP.NET

These are the starter files for my "Building a Consistent RESTful API with OData V4 in ASP.NET" course at Pluralsight (https://app.pluralsight.com/library/courses/asp-dot-net-odata-v4-restful-api/table-of-contents).
